<?php
namespace api\controllers;

use Yii;
use yii\db;
use yii\web\Controller;

header('content-type:text/html;charset=utf-8');

class ExamController extends Controller{

	public $enableCsrfValidation  = false;

	// 文件上传，数据入库
	public function actionAddtest(){
		// var_dump($_FILES);die;

		$dir='/phpstudy/www/yii2/api/upload/excel.xls';

        $month = Yii::$app->request->post('month');
        $unit = Yii::$app->request->post('unit');

        $reg = move_uploaded_file($_FILES['excel']['tmp_name'], $dir);

        //引入excel操作类
        require(__DIR__ . '/../../common/lib/PHPExcel.php');
        // $excel = new \PHPExcel();

        $objPHPExcel = \PHPExcel_IOFactory::load($dir);

        //当前页面试题
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
        unset($sheetData[1]);

        $type = array_flip(Yii::$app->params['type']);

        $score =Yii::$app->params['score']; 

        foreach ($sheetData as $k => $v) {
        	$tem=array(
        		'title'=>$v['C'],
        		'type'=>$type[$v['B']],	//题目类型
        		'month'=>$month,
        		'unit'=>$unit,
        		'add_time'=>time()
        	);

        	$res=yii::$app->db->createCommand()->insert('stem',$tem)->execute();
        	$id=yii::$app->db->getLastInsertID();
        	
        	$num_id=array('D'=>'A','E'=>'B','F'=>'C','G'=>'D','H'=>'E','I'=>'F');

        	//正确答案
        	$yesinfo = str_split($v['J'], 1);

        	// 试题答案
        	for($i = 'D'; $i<= 'I'; $i++){

        		if(empty($v[$i])) continue;
        		
        		$is_yes = in_array($num_id[$i], $yesinfo) ? 1 : 0;

        		$answer = array(
        			'tm_id'=>$id,
        			'chose'=>$num_id[$i],
        			'option'=>$v[$i],
        			'is_yes'=>$is_yes
        		);

        		$info = yii::$app->db->createCommand()->insert('answer', $answer)->execute();
        	}
        }

        if($res && $info){
        	echo 1;
        }
	}

	// 显示数据
	public function actionSelect(){

		$data=yii::$app->db->createCommand("select * from stem")->queryAll();

		$chose=array(
			'0'=>'A',
			'1'=>'B',
			'2'=>'C',
			'3'=>'D',
			'4'=>'E',
			'5'=>'F',
		);

		foreach ($data as $k => $v) {
			$id=$v['tm_id'];

			$info=yii::$app->db->createCommand("select * from answer where tm_id = $id")->queryAll();

			foreach ($info as $key => $val) {
				$data[$k]['mold'][$chose[$key]]=$val['option'];

				if($val['is_yes']=='1' && $val['tm_id']==$v['tm_id']){
					$data[$k]['is_yes']=$val['chose'];
				}
			}
		}

		echo json_encode($data);
	}
}