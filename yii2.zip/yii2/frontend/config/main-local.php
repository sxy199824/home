<?php
return [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'evw24tcimWWOw0XZGHvhkDDT_xM4K95n',
        ],
    ],
];
