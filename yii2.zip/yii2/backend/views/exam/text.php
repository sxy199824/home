<!DOCTYPE html>
<html>
<head>
	<title>第一单元</title>
</head>
<body>
<form action="?r=exam/text" method="post">
<table>
	<?php foreach ($data as $k => $v) {  ?>
	<div class="panel panel-default">
		    <div class="panel-heading"><?=$k+1;?>.(<?=yii::$app->params['type'][$v['type']];?>) <?=$v['title'];?></div>
			    <?php if($v['type']=='p-2'){ ?>
					<?php foreach ($v['mold'] as $key => $val) { ?>
					<ul class="list-group">
				        <li class="list-group-item" align="left">&nbsp;&nbsp;<input type="checkbox" name="<?=$v['tm_id'];?>[]" value="<?=$key;?>"><?=$key;?>、<?=$val;?></li>
				    </ul>
					<?php } ?>
				<?php }else{ ?>
					<?php foreach ($v['mold'] as $key => $val) { ?>
					<li class="list-group-item">&nbsp;&nbsp;<input type="radio" name="<?=$v['tm_id'];?>" value="<?=$key;?>"><?=$key;?>、<?=$val;?></li>
					<?php } ?>
				<?php } ?>
					<li class="list-group-item">正确答案:<?=$v['is_yes'];?></li>
			</div>
	<?php } ?>
	<tr>
		<td align="center"><button type="submit" class="btn btn-primary btn-lg btn-block">提交试卷</button></td>
	</tr>
</table>
</form>
</body>
</html>