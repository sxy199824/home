<!DOCTYPE html>
<html>
<head>
   <title>首页</title>
   <link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css">
   <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
   <script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body>

<p align="right"><a href="?r=exam/upload"><button type="button" class="btn btn-primary">上传文件</button></a></p>

<table class="table table-striped">
   <thead>
      <tr>
         <th>名称</th>
         <th>文件</th>
         <th>操作</th>
      </tr>
   </thead>
   <tbody>
      <tr>
         <td>第一单元</td>
         <td><a href="javascript:void(0)">缓存到本地</a></td>
         <td><a href="?r=exam/text">点我查看</a></td>
      </tr>
   </tbody>
</table>
 
</body>
</html>