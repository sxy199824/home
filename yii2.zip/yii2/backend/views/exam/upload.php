<!DOCTYPE html>
<html>
<head>
   <title>上传文件</title>
   <link rel="stylesheet" href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css">
   <script src="http://apps.bdimg.com/libs/jquery/2.1.1/jquery.min.js"></script>
   <script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body>
 
<form role="form" action="?r=exam/upload" method="post" enctype="multipart/form-data">
   <div class="form-group">
      <label for="name">教学月</label>
      <select name="month">
         <option>-----请选择-----</option>
         <option value="9">9月</option>
         <option value="10">10月</option>
         <option value="11">11月</option>
      </select>
   </div>
   <div class="form-group">
      <label for="name">单元</label>
      <select name="unit">
         <option>-----请选择-----</option>
         <?php foreach (Yii::$app->params['unit'] as $key => $value) { ?>
            <option value="<?=$key;?>"><?=$value;?></option>
         <?php } ?>
      </select>
   </div>
   <div class="form-group">
      <label for="inputfile">文件输入</label>
      <input type="file" name="file">
   </div>
   <button type="submit" class="btn btn-default">上传</button>
</form>
 
</body>
</html>